/* 
 * File:   sales.h
 * Author: Abdul-Hakim
 * Purpose: Ch_12_Prob_11 
 * Created on September 25, 2015, 1:43 AM
 */

#ifndef SALES_H
#define	SALES_H

struct Sales{
    
    std::string divNm;
    short int qtr;
    float qSales; 
    
};

#endif	/* SALES_H */

