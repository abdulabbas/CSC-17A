/* 
 * File:   IndexedColumn.h
 * Author: Abdul-Hakim
 * Created on October 8, 2015, 10:19 PM
 */

#ifndef INDEXEDCOLUMN_H
#define	INDEXEDCOLUMN_H
struct IndxCol{
    int size;
    int *array;
    int *indx;
};
#endif	/* INDEXEDCOLUMN_H */

